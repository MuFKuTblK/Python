# import math
# a=-1.9
# b=2.7
# h=0.3
# while b>a:
#     Y=((a**2/4)+a/2-3)*math.e**(a/2)
#     a = a+h
#     print(f'Y={Y}')
import math
a=0.1
b=1
h=0.1
k=0
total=0
while a<b:
    S=((2*k+1)/math.factorial(k))*a**(2*k)
    Y=(1+2*a**2)*math.e**(a**2)
    a+=h
    if math.floor(a) == b:
        break
    total += S
    print (f'total={total}')
    # print(f'S={S}')
