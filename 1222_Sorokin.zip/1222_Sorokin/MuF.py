import math
# z = int(input("Введите значение z="))
# if z < 0:
#     x = z
# else:
#     x = math.sin(z)
# y = 2 / 3 * math.sin(x) ** 2 - 3 / 4 * math.cos(x) ** 2
# print(f'y{y}')
try:
    x=int(input("Введите значение x="))
    y=int(input("Введите значение y="))
    z=int(input("Введите значение z="))
    m = min(y, z) / max(min(x, y), min(y, z))
    print(f'm={m}')
    if y < z:
        min1 = y
    else:
        min1 = z
    if x < y:
        min2 = x
    else:
        min2 = y
    if y < z:
        min3 = y
    else:
        min3 = z
    if min2 > min3:
        max1 = min2
    else:
        max1 = min3
    m1 = min1 / max1
    print(f'm1={m1}')
except ValueError:
    print("Это не число, братишка")
else:
    print("Так то лучше")