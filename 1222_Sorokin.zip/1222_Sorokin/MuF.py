# isGood = True
# print(isGood)
#
# isAlive = False
# print(isAlive)
#
# myAge = 17
# print("Возраст:", myAge)
#
# myCount = 20
# print("Количество:", myCount)
#
# myNumber = input("Какой у меня номер?")
# print(myNumber)
#
# myAge=input("Введите свой возраст")
# print("Ваш возраст",myAge)
#
# import math
# a=int(input("Введите своё значение a="))
# b=int(input("Введите своё значение b="))
# z1 = math.cos(a)+math.cos(2*a)+math.cos(6*a)+math.cos(7*a)
# z2 = 4*math.cos(a/2)*math.cos(5/2*a)*math.cos(4*a)
# print(f'z1:{z1}')
# print(f'z2:{z2}')
import math
x=float(input("Введите своё значение x="))
y=float(input("Введите своё значение y="))
z=float(input("Введите своё значение z="))
g=y**(x+1)/abs(y-2)**(1./3.)+3 + (x+y/2)/2*abs(x+y) * (x+1)**(-1/math.sin(z))
print(f'g:{g}')
# import math
# x=int(input("Введите своё значение x="))
# y=int(input("Введите своё значение y="))
# z=int(input("Введите своё значение z="))
# w=(x**6+math.log(y)**2)(1./3.) + math.exp()
