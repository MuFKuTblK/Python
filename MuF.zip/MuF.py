import math
a = 100
b = 50
c = 2
print (math.factorial(15))
print(a+b)
print(a-b)
print(a*b)
print(a**b)
print(math.factorial(b))
print(math.sqrt(a))
print(math.gamma(b))
print(math.sin(c))
print(math.radians(20))
print(math.exp(5))