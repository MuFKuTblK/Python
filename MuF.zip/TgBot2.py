import telebot
import random


bot = telebot.TeleBot('6271776348:AAEItyU4SgcVIhNp_02tdebHB5Px_yRDcyk')
colors=['Красный','Синий','Белый','Оранжевый','Зелёный','Жёлтый']
colorsreturn=[]
for item in colors:
    colorsreturn.append(item)
str=''
item=''
@bot.message_handler(commands=["start"])
def start(m, res=False):
    bot.send_message(m.chat.id, 'Нажмите 1 чтобы зарандомить:\nНажмите 2 чтобы добавить элемент:\nНажмите 3 ' 'чтобы удалить элемент:')
@bot.message_handler(content_types=["text"])
def handle_text(message):
    if message.text == '1':
        bot.send_message(message.chat.id, 'Я зарандомил: ' + RandomElement())
    if message.text == '2':
        bot.send_message(message.chat.id, 'Напишите цвет ')
        bot.register_next_step_handler(message, AddElement)
    if message.text == '3':
        bot.send_message(message.chat.id, 'Напишите цвет, который надо удалить')
        bot.register_next_step_handler(message, RemoveElement)
def RandomElement():
    if len(colorsreturn) != 0:
        index = random.randint(0, len(colorsreturn) - 1)
        str = colorsreturn[index]
        colorsreturn.remove(colorsreturn[index])
        return str
    else:
        for item in colors:
            colorsreturn.append(item)
        index = random.randint(0, len(colorsreturn) - 1)
        str = colorsreturn[index]
        colorsreturn.remove(colorsreturn[index])
        return str
def AddElement(message):
    global item
    item = message.text
    if not colors.__contains__(item):
        colors.append(item)
        colorsreturn.append(item)
        bot.send_message(message.from_user.id, f'Добавил цвет {message.text}');
    else:
        bot.send_message(message.from_user.id, f'Цвета не существует в списке, хотите добавлю?(Скажите да)');
        bot.register_next_step_handler(message, AddElement)


bot.polling(none_stop=True, interval=0)
