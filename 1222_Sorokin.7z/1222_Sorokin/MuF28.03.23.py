import math
string = input()
if string.__len__() % 2 == 0:
    string.split(" ")
a = string.lower()
j=0